let confetes = [];
let acertos = 0;
let erro = 0;
let maxConfetes = 8; // Numero de confete 
let gameOver = false;
let venceu = false;
let botoes = []; 
let tempo = 60; // duração
let tempoInicial; // tempo que se inicia
let confetesPorAcerto = 2; 
let tela = "intro"; // "intro", "inicio", "instrucoes", "jogo", "venceu", "perdeu"

// Variaveis de botão
let botaoComecar, botaoInstrucoes, botaoVoltar, botaoContinuarIntro, botaoVoltarJogo;

let milho = [];
let milhoColhido = 0;
let milhoMeta = 5; // meta de milho

let fogueiraClicks = 0;
let fogueiraAcesa = false;

let balao = [];
let balaoPegos = 0;
let balaoMeta = 3; // balões coletados

let doces = [];
let docesPegos = 0;
let docesMeta = 4; // meta de balas

let introParticles = [];
let maxIntroParticles = 15; // particulas

let floatingElements = [];
let maxFloatingElements = 8; 

// efeito "Quentão" 
let confeteSpeedMultiplier = 1.0; // Base speed multiplier for confetti
let quentaoActive = false; // Is Quentão effect active?
let quentaoStartTime; // Timestamp when Quentão effect started
const QUENTAO_DURATION = 5000; // Quentão effect duration in milliseconds (5 seconds)
const QUENTAO_SPEED_DEBUFF = 0.4; // Confetti speed multiplier when Quentão is active

// Arrays to store temporary visual effects
let clickParticles = []; // For milho, balao, doce
let bonfireParticles = []; // For fogueira clicks

function setup() {
  // Set up the canvas and initial UI elements
  createCanvas(800, 400);
  textAlign(CENTER, CENTER);
  angleMode(DEGREES); // Use degrees for easier rotation (e.g., for rotations)

  // Initialize intro particles for visual flair
  for (let i = 0; i < maxIntroParticles; i++) {
    introParticles.push(new IntroParticle());
  }

  // Initialize floating elements for the initial screen background
  for (let i = 0; i < maxFloatingElements; i++) {
    floatingElements.push(new FloatingElement());
  }

  // --- Button Definitions ---

  // "Continue" button for the introductory screen
  botaoContinuarIntro = createButton('Continuar');
  botaoContinuarIntro.position(width / 2 - 60, height / 2 + 100);
  botaoContinuarIntro.class('game-button'); // Apply CSS styling
  botaoContinuarIntro.mousePressed(() => {
    tela = "inicio"; // Move to the main menu screen
    botaoContinuarIntro.hide(); // Hide itself
    botaoComecar.show(); // Show main menu buttons
    botaoInstrucoes.show();
  });

  // "Start Game" button (initially hidden, shown on 'inicio' screen)
  botaoComecar = createButton('Começar a Festa!');
  botaoComecar.position(width / 2 - 60, height / 2 + 50);
  botaoComecar.class('game-button');
  botaoComecar.mousePressed(() => {
    tela = "jogo"; // Start the game
    botaoComecar.hide(); // Hide main menu buttons
    botaoInstrucoes.hide();
    tempoInicial = millis(); // Record game start time
    criarBotoes(); // Create in-game action buttons
    // Initialize all game elements for a fresh start
    for (let i = 0; i < maxConfetes; i++) confetes.push(new Confete());
    for (let i = 0; i < milhoMeta; i++) milho.push(new Milho());
    for (let i = 0; i < balaoMeta; i++) balao.push(new Balao());
    for (let i = 0; i < docesMeta; i++) doces.push(new Doce());
    botaoVoltarJogo.show(); // Show the in-game back button
  });
  botaoComecar.hide(); // Hidden until 'inicio' screen

  // "Instructions" button (initially hidden, shown on 'inicio' screen)
  botaoInstrucoes = createButton('Instruções');
  botaoInstrucoes.position(width / 2 - 60, height / 2 + 90);
  botaoInstrucoes.class('game-button');
  botaoInstrucoes.mousePressed(() => {
    tela = "instrucoes"; // Go to instructions screen
    botaoComecar.hide(); // Hide main menu buttons
    botaoInstrucoes.hide();
    botaoVoltar.show(); // Show back button for instructions
  });
  botaoInstrucoes.hide(); // Hidden until 'inicio' screen

  // "Back" button for the instructions screen (initially hidden)
  botaoVoltar = createButton('Voltar');
  botaoVoltar.position(width / 2 - 60, height / 2 + 120);
  botaoVoltar.class('game-button');
  botaoVoltar.mousePressed(() => {
    tela = "inicio"; // Return to main menu
    botaoComecar.show(); // Show main menu buttons
    botaoInstrucoes.show();
    botaoVoltar.hide(); // Hide itself
  });
  botaoVoltar.hide(); // Hidden until 'instrucoes' screen

  // "Back to Menu" button for the game screen (initially hidden)
  botaoVoltarJogo = createButton('Voltar ao Menu');
  botaoVoltarJogo.position(width - 150, 20); // Position at top-right
  botaoVoltarJogo.class('game-button');
  botaoVoltarJogo.mousePressed(() => {
    tela = "inicio"; // Return to main menu
    resetGame(); // Reset all game-related states
    // Hide all game-specific buttons and show main menu buttons
    botoes.forEach(btn => btn.hide());
    botaoVoltarJogo.hide();
    botaoComecar.show();
    botaoInstrucoes.show();
  });
  botaoVoltarJogo.hide(); // Hidden until 'jogo' screen
}

function draw() {
  // Main draw loop, controls screen transitions and content
  background('#FDF2E9'); // Light background for all screens

  // Display content based on the current 'tela' state
  if (tela === "intro") {
    telaIntro();
  } else if (tela === "inicio") {
    telaInicial();
  } else if (tela === "instrucoes") {
    telaInstrucoes();
  } else if (tela === "jogo") {
    telaJogo();
  } else if (tela === "venceu") {
    telaFinal(true); // Player won
  } else if (tela === "perdeu") {
    telaFinal(false); // Player lost
  }
}

// --- Screen Functions ---

function telaIntro() {
  // New introductory screen with a welcoming message and charity theme
  drawCenario(); // Draw the festive background

  // Animate particles to add a dynamic feel to the intro
  introParticles.forEach(p => {
    p.move();
    p.show();
    if (p.isOffscreen()) {
      p.reset(); // Reset particles that fall off screen
    }
  });

  // Main title with a subtle pulsing animation
  let pulse = sin(frameCount * 5) * 5; // Controls pulse speed and amplitude
  textSize(45 + pulse);
  fill('#D35400'); // Dark orange for title
  text('A Festa Junina está rolando na cidade!', width / 2, height / 2 - 100);

  // Subtitle
  textSize(25);
  fill(0); // Black for subtitle
  text('Prepare-se para a diversão!', width / 2, height / 2 - 50);

  // Informative text about the importance of charity festivals
  textSize(18);
  fill('#154360'); // Dark blue
  text('As festas beneficentes são essenciais para a comunidade,', width / 2, height / 2 + 10);
  text('ajudando a cidade e o campo com alegria e união!', width / 2, height / 2 + 35);

  // Informative text about city-countryside friendship
  textSize(18);
  fill('#154360'); // Dark blue
  text('A amizade entre a cidade e o campo fortalece nossos laços', width / 2, height / 2 + 60);
  text('e celebra a riqueza de nossa cultura e tradições!', width / 2, height / 2 + 85);
}

function telaInicial() {
  // Main menu screen with game title and a brief objective
  drawCenario(); // Draw the festive background

  // Animate floating elements for visual interest
  floatingElements.forEach(e => {
    e.move();
    e.show();
    // Floating elements bounce, so no need to reset offscreen
  });

  // Game title with a subtle bounce animation
  let bounce = sin(frameCount * 3) * 2; // Controls bounce speed and amplitude
  textSize(40);
  fill('#D35400'); // Dark orange
  text('Bem-vindo à Festa Junina Interativa!', width / 2, height / 2 - 80 + bounce);

  textSize(20);
  fill(0); // Black
  text('Clique nos confetes, colha milhos, acenda a fogueira, capture balões e pegue doces!', width / 2, height / 2 - 40);
}

function telaInstrucoes() {
  // Instructions screen detailing game mechanics
  drawCenario(); // Draw the festive background
  fill('#154360'); // Dark blue for title
  textSize(28);
  text('Instruções da Festa:', width / 2, 50);
  textSize(18);
  fill(0); // Black for instruction text
  text("- Clique nos confetes que caem do céu para manter a animação.", width / 2, 100);
  text("- Colete milhos clicando neles no canto direito da tela.", width / 2, 130);
  text("- Acenda a fogueira clicando 10 vezes nela.", width / 2, 160);
  text("- Capture balões que sobem pela tela.", width / 2, 190);
  text("- Pegue doces no canto esquerdo inferior.", width / 2, 220);
  text("- Você tem 60 segundos para completar tudo e manter a festa viva!", width / 2, 260);
}

function telaFinal(venceuFlag) {
  // Final screen displayed upon winning or losing the game
  drawCenario(); // Draw the festive background
  textSize(40);
  fill(venceuFlag ? 'green' : 'red'); // Green for win, red for lose
  text(venceuFlag ? 'Você manteve a festa viva! 🎉' : 'A energia da festa acabou! 😭', width / 2, height / 2);

  // Hide any existing game-specific buttons
  botoes.forEach(btn => btn.hide());
  botaoVoltarJogo.hide();

  // Create and show "Play Again" button for restarting
  let btn = createButton('Jogar novamente');
  btn.position(width / 2 - 60, height / 2 + 60);
  btn.class('game-button');
  btn.mousePressed(() => location.reload()); // Reloads the page to restart the game
  noLoop(); // Stop the draw loop as the game has ended
}

function telaJogo() {
  // Main game screen logic: updates and displays game elements and stats
  drawCenario(); // Draw the festive background

  // Update confetti speed based on hits (dynamic difficulty)
  confeteSpeedMultiplier = 1.0 + (acertos * 0.01); // 1% speed increase per hit

  // Check and apply "Quentão" effect
  if (quentaoActive) {
    if (millis() - quentaoStartTime > QUENTAO_DURATION) {
      quentaoActive = false; // End effect
    } else {
      confeteSpeedMultiplier *= QUENTAO_SPEED_DEBUFF; // Apply slow debuff
    }
  }

  // Calculate and display remaining time
  let tempoRestante = tempo - int((millis() - tempoInicial) / 1000);
  if (tempoRestante <= 0) {
    // Check win conditions when time runs out
    if (milhoColhido >= milhoMeta && fogueiraAcesa && balaoPegos >= balaoMeta && docesPegos >= docesMeta) {
      tela = "venceu";
    } else {
      tela = "perdeu";
    }
    // Hide all game-specific buttons immediately
    botoes.forEach(btn => btn.hide());
    botaoVoltarJogo.hide();
  }

  // Update and display confetti, remove if off-screen
  for (let i = confetes.length - 1; i >= 0; i--) {
    confetes[i].move(confeteSpeedMultiplier); // Pass multiplier to confetti
    confetes[i].show();
    if (confetes[i].foraDaTela()) {
      confetes.splice(i, 1);
      erro++; // Increment error count if confetti is missed
    }
  }

  // Display other interactive game elements
  milho.forEach(m => m.show());
  balao.forEach(b => {
    b.move();
    b.show();
  });
  doces.forEach(d => d.show());

  // Update and display temporary particles (for clicks and bonfire)
  for (let i = clickParticles.length - 1; i >= 0; i--) {
    clickParticles[i].update();
    clickParticles[i].display();
    if (clickParticles[i].isFinished()) {
      clickParticles.splice(i, 1);
    }
  }

  for (let i = bonfireParticles.length - 1; i >= 0; i--) {
    bonfireParticles[i].update();
    bonfireParticles[i].display();
    if (bonfireParticles[i].isFinished()) {
      bonfireParticles.splice(i, 1);
    }
  }


  // Check for too many errors (missed confetti)
  if (erro >= 50) {
    tela = "perdeu"; // Transition to lose screen
    // Hide all game-specific buttons
    botoes.forEach(btn => btn.hide());
    botaoVoltarJogo.hide();
  }

  // Display current game statistics
  fill(0); // Black text color
  textSize(18);
  text(`Confetes: ${acertos}`, 100, 30);
  text(`Erros: ${erro}`, 250, 30);
  text(`Tempo: ${tempoRestante}s`, 400, 30);
  text(`Milhos: ${milhoColhido}/${milhoMeta}`, 100, 60);
  text(`Fogueira: ${fogueiraAcesa ? 'Acesa 🔥' : `${fogueiraClicks}/10 cliques`}`, 300, 60);
  text(`Balões: ${balaoPegos}/${balaoMeta}`, 500, 60);
  text(`Doces: ${docesPegos}/${docesMeta}`, 600, 60);
}

function mousePressed() {
  // Event handler for mouse clicks, only active in game mode
  if (tela !== "jogo") return; // Ignore clicks if not in game

  // Check for confetti clicks (iterating backwards for safe removal)
  for (let i = confetes.length - 1; i >= 0; i--) {
    if (confetes[i].clicado(mouseX, mouseY)) {
      acertos++; // Increment hits
      confetes.splice(i, 1); // Remove clicked confetti
      // Add more confetti to keep the game going, up to a max
      for (let j = 0; j < confetesPorAcerto; j++) {
        if (confetes.length < 50) { // Limit total confetti on screen
          confetes.push(new Confete());
        }
      }
      break; // Process only one click per mouse press
    }
  }

  // Check for milho clicks
  for (let i = milho.length - 1; i >= 0; i--) {
    if (milho[i].clicado(mouseX, mouseY)) {
      milho.splice(i, 1); // Remove clicked corn
      milhoColhido++; // Increment collected corn
      // Add particle effect for milho
      for(let k=0; k<8; k++) clickParticles.push(new ClickParticle(mouseX, mouseY, color(255, 223, 0))); // Yellow particles
      break;
    }
  }

  // Check for bonfire clicks within its defined area
  if (mouseX > 90 && mouseX < 150 && mouseY > height - 120 && mouseY < height - 50) {
    fogueiraClicks++; // Increment click count
    // Add particle effect for bonfire clicks
    if (!fogueiraAcesa) { // Only add particles if not yet lit
      for(let k=0; k<5; k++) bonfireParticles.push(new BonfireParticle(120, height - 60)); // Around bonfire position
    }
    if (fogueiraClicks >= 10) {
      fogueiraAcesa = true; // Light the bonfire after 10 clicks
    }
  }

  // Check for balloon clicks
  for (let i = balao.length - 1; i >= 0; i--) {
    if (balao[i].clicado(mouseX, mouseY)) {
      // FIX: Get the balloon's color before it's removed
      let clickedBalaoColor = balao[i].color;
      balao.splice(i, 1); // Remove clicked balloon
      balaoPegos++; // Increment collected balloons
      // Add particle effect for balloon using its color
      for(let k=0; k<10; k++) clickParticles.push(new ClickParticle(mouseX, mouseY, clickedBalaoColor, 'circle'));
      break;
    }
  }

  // Check for candy clicks
  for (let i = doces.length - 1; i >= 0; i--) {
    if (doces[i].clicado(mouseX, mouseY)) {
      doces.splice(i, 1); // Remove clicked candy
      docesPegos++; // Increment collected candies
      // Add particle effect for candy
      for(let k=0; k<12; k++) clickParticles.push(new ClickParticle(mouseX, mouseY, color(random(255), 100, random(255), 200), 'star')); // Pinkish star particles
      break;
    }
  }
}

/**
 * Resets all game-related variables and arrays to their initial states,
 * preparing for a new game.
 */
function resetGame() {
  acertos = 0;
  erro = 0;
  gameOver = false;
  venceu = false;
  tempo = 60; // Reset timer duration
  tempoInicial = null; // Clear initial time reference
  milhoColhido = 0;
  fogueiraClicks = 0;
  fogueiraAcesa = false;
  balaoPegos = 0;
  docesPegos = 0;

  // Reset dynamic difficulty and Quentão effect
  confeteSpeedMultiplier = 1.0;
  quentaoActive = false;
  quentaoStartTime = null;

  // Clear all dynamic game element arrays
  confetes = [];
  milho = [];
  balao = [];
  doces = [];
  clickParticles = [];
  bonfireParticles = [];

  // Ensure the draw loop is active if it was paused (e.g., after game over)
  loop();
}

// --- Game Element Classes ---

// Confete class for falling confetti
class Confete {
  constructor() {
    this.x = random(50, width - 50);
    this.y = random(-200, -50); // Start above the canvas
    this.baseSpeed = random(1.5, 3.5); // Base movement speed
    this.size = random(25, 40); // Size of the confetti
    this.cor = color(random(255), random(255), random(255), 200); // Random transparent color
    this.shape = floor(random(4)); // 0: circle, 1: square, 2: triangle, 3: star
    this.rotation = random(360); // Initial random rotation
    this.rotationSpeed = random(-3, 3); // Rotation speed and direction
  }

  show() {
    push(); // Isolate transformations for this object
    translate(this.x, this.y);
    rotate(this.rotation);
    fill(this.cor);
    stroke(this.cor.levels[0] * 0.8, this.cor.levels[1] * 0.8, this.cor.levels[2] * 0.8, 255); // Darker stroke for definition
    strokeWeight(1);

    // Add a subtle shadow for depth
    drawingContext.shadowOffsetX = 2;
    drawingContext.shadowOffsetY = 2;
    drawingContext.shadowBlur = 5;
    drawingContext.shadowColor = 'rgba(0, 0, 0, 0.3)';

    // Draw different shapes based on this.shape
    if (this.shape === 0) {
      ellipse(0, 0, this.size);
    } else if (this.shape === 1) {
      rectMode(CENTER);
      rect(0, 0, this.size, this.size);
    } else if (this.shape === 2) {
      triangle(0, -this.size / 2, -this.size / 2, this.size / 2, this.size / 2, this.size / 2);
    } else { // Star shape
      let outerRadius = this.size / 2;
      let innerRadius = outerRadius * 0.4; // Inner radius for sharper points
      let numPoints = 5; // Number of star points
      beginShape();
      for (let a = 0; a < 360; a += 360 / (numPoints * 2)) {
        let radius = (a % (360 / numPoints) === 0) ? outerRadius : innerRadius;
        let sx = cos(a) * radius;
        let sy = sin(a) * radius;
        vertex(sx, sy);
      }
      endShape(CLOSE);
    }
    pop(); // Restore previous transformations
  }

  move(speedMultiplier = 1.0) {
    this.y += this.baseSpeed * speedMultiplier; // Move downwards, affected by multiplier
    this.rotation += this.rotationSpeed; // Rotate
  }

  foraDaTela() {
    return this.y > height; // Check if confetti is off the bottom of the screen
  }

  clicado(mx, my) {
    return dist(mx, my, this.x, this.y) < this.size / 2; // Check if mouse clicked within confetti radius
  }
}

// Milho class for corn cobs to be collected
class Milho {
  constructor() {
    this.x = random(650, 780); // Position on the right side
    this.y = random(height - 60, height - 30); // Position near the bottom ground
  }

  show() {
    push();
    translate(this.x, this.y);
    rotate(random(-5, 5)); // Slight random rotation for natural look

    // Corn cob body
    fill('#FFD700'); // Yellow
    stroke('#DAA520'); // Darker yellow for texture
    strokeWeight(1);
    ellipse(0, 0, 25, 50); // Main oval shape

    // Corn kernels (small ellipses)
    fill('#DAA520');
    noStroke();
    let kernelSize = 4;
    for (let r = -20; r <= 20; r += kernelSize * 1.5) {
      for (let c = -10; c <= 10; c += kernelSize * 1.5) {
        ellipse(c, r, kernelSize, kernelSize);
      }
    }

    // Green leaves/husks
    fill('#228B22'); // Forest green
    noStroke();
    // Left leaf shape (using bezier curves for organic feel)
    beginShape();
    vertex(-15, 10);
    bezierVertex(-30, -5, -20, -30, -5, -25);
    vertex(-10, 0);
    endShape(CLOSE);
    // Right leaf shape
    beginShape();
    vertex(15, 10);
    bezierVertex(30, -5, 20, -30, 5, -25);
    vertex(10, 0);
    endShape(CLOSE);

    pop();
  }

  clicado(mx, my) {
    return dist(mx, my, this.x, this.y) < 25; // Clickable area
  }
}

// Balao class for hot air balloons
class Balao {
  constructor() {
    this.x = random(100, 700);
    this.y = random(-100, -40); // Start above the canvas
    this.speed = random(1, 2); // Upward movement speed
    this.color = color(random(255), random(255), random(255)); // Random main color
    this.patternType = floor(random(2)); // 0: stripes, 1: polka dots
  }

  move() {
    this.y += this.speed; // Move upwards
    // If balloon goes off the bottom, reset its position to appear again from top
    if (this.y > height + 50) {
      this.y = random(-100, -40);
      this.x = random(100, 700);
      this.speed = random(1, 2);
      this.color = color(random(255), random(255), random(255)); // New random color
      this.patternType = floor(random(2)); // New random pattern
    }
  }

  show() {
    push();
    translate(this.x, this.y);

    // Balloon body (ellipse)
    fill(this.color);
    stroke(0);
    strokeWeight(1.5);
    ellipse(0, 0, 50, 60);

    // Add patterns based on type
    if (this.patternType === 0) { // Stripes
      fill(255, 255, 255, 150); // Transparent white stripes
      for (let i = -20; i <= 20; i += 10) {
        rect(i - 2, -30, 5, 60);
      }
    } else { // Polka dots
      fill(255, 255, 255, 150); // Transparent white dots
      for (let i = -15; i <= 15; i += 15) {
        for (let j = -20; j <= 20; j += 15) {
          ellipse(i, j, 8, 8);
        }
      }
    }

    // Small triangle connecting balloon to strings
    fill(this.color);
    noStroke();
    triangle(-20, 30, 20, 30, 0, 35);

    // Strings to basket
    stroke(0);
    strokeWeight(1);
    line(-15, 25, -10, 40);
    line(15, 25, 10, 40);

    // Basket (rounded rectangle)
    fill('#8B4513'); // Brown
    stroke(0);
    strokeWeight(1);
    rectMode(CENTER);
    rect(0, 50, 30, 20, 5); // Rounded corners

    pop();
  }

  clicado(mx, my) {
    return dist(mx, my, this.x, this.y) < 30; // Clickable area for the balloon
  }
}

// Doce class for candies to be collected
class Doce {
  constructor() {
    this.x = random(50, 200); // Position on the left side
    this.y = random(300, 360); // Position near the bottom ground
    this.color = color(random(200, 255), random(100, 200), random(100, 200)); // Vibrant candy colors
  }

  show() {
    push();
    translate(this.x, this.y);
    rotate(random(-10, 10)); // Slight random rotation for natural look

    // Candy body (rounded rectangle)
    fill(this.color);
    stroke('#8B0000'); // Dark red outline
    strokeWeight(1.5);
    rectMode(CENTER);
    rect(0, 0, 35, 20, 5);

    // Candy wrapper ends (triangles)
    fill(this.color);
    noStroke();
    triangle(-18, -10, -28, -15, -28, 15);
    triangle(18, -10, 28, -15, 28, 15);

    // Wrapper details (crinkles)
    stroke(255, 100);
    strokeWeight(0.8);
    line(-20, -8, -25, -13);
    line(-20, 8, -25, 13);
    line(20, -8, 25, -13);
    line(20, 8, 25, 13);

    // Glossy highlight for a shiny effect
    fill(255, 255, 255, 150);
    ellipse(-8, -5, 5, 3);
    ellipse(5, -3, 8, 4);

    pop();
  }

  clicado(mx, my) {
    return dist(mx, my, this.x, this.y) < 20; // Clickable area for the candy
  }
}

/**
 * Creates and positions the interactive buttons for the game
 * (Pamonha, Forró, Feno, Quentão, Quadrilha).
 * Clears existing buttons before creating new ones to prevent duplicates.
 */
function criarBotoes() {
  const buttonLabels = ['Pamonha', 'Forró', 'Feno', 'Quentão', 'Quadrilha'];
  // Remove any previously created buttons to avoid issues on game restart
  botoes.forEach(btn => btn.remove());
  botoes = []; // Clear the array

  for (let i = 0; i < buttonLabels.length; i++) {
    let btn = createButton(buttonLabels[i]);
    btn.position(50 + i * 140, height - 40); // Position buttons horizontally
    btn.class('game-button'); // Apply CSS styling

    // Special behavior for the "Quentão" button
    if (buttonLabels[i] === 'Quentão') {
      btn.mousePressed(() => {
        if (!quentaoActive) { // Activate Quentão effect only if not already active
          quentaoActive = true;
          quentaoStartTime = millis();
          // Optionally add a visual/sound cue for Quentão activation
        }
        // Also add confetti as a general button action
        for (let j = 0; j < 2; j++) {
          if (confetes.length < 50) {
            confetes.push(new Confete());
          }
        }
      });
    } else { // Normal behavior for other buttons
      btn.mousePressed(() => {
        // When a button is pressed, add more confetti (up to maxConfetes limit)
        for (let j = 0; j < 2; j++) {
          if (confetes.length < 50) { // Keep total confetti reasonable
            confetes.push(new Confete());
          }
        }
      });
    }
    botoes.push(btn); // Store reference to the created button
  }
}

/**
 * Draws the recurring festive background elements for all game screens.
 */
function drawCenario() {
  // Sky gradient from light blue to lighter blue
  for (let i = 0; i < height - 50; i++) {
    let inter = map(i, 0, height - 50, 0, 1);
    let c = lerpColor(color('#87CEEB'), color('#ADD8E6'), inter);
    stroke(c);
    line(0, i, width, i);
  }

  // Clouds with transparency
  fill(255, 250);
  noStroke();
  ellipse(150, 80, 80, 50);
  ellipse(180, 60, 70, 40);
  ellipse(120, 70, 60, 35);

  ellipse(600, 100, 90, 60);
  ellipse(630, 80, 80, 50);
  ellipse(570, 90, 70, 40);

  // Festive flags (bunting) at the top with more varied animation
  let flagColors = ['#FF5733', '#FFC300', '#DAF7A6', '#C70039', '#3498DB', '#2ECC71'];
  stroke(50); // String color
  strokeWeight(1);
  line(0, 20, width, 20); // Main string across the top

  for (let i = 0; i < width; i += 40) {
    fill(flagColors[floor((i / 40 + frameCount * 0.1) % flagColors.length)]); // Cycle colors
    noStroke();
    push();
    translate(i + 20, 20);
    // More complex swaying animation for flags
    let swayAngle = sin(frameCount * (2 + i * 0.005) + i * 0.1) * 8; // Varied speed and amplitude
    rotate(swayAngle);
    triangle(-15, 0, 0, 25, 15, 0); // Flag shape
    pop();
  }

  // Twinkling Lights (new background detail)
  for (let i = 0; i < 20; i++) {
    let x = random(width);
    let y = random(0, height * 0.6); // Upper part of the sky
    let blink = sin(frameCount * random(5, 15) + x + y) * 0.5 + 0.5; // Pulsing effect
    fill(255, 255, 0, 100 + blink * 150); // Yellowish, transparent, blinking
    noStroke();
    ellipse(x, y, 3, 3);
  }


  // Ground (brown rectangle)
  fill('#8B4513'); // Brown
  noStroke();
  rect(0, height - 50, width, 50);

  // Bonfire drawing
  push();
  translate(120, height - 60); // Position the bonfire (relative to ground)
  if (fogueiraAcesa) {
    // Lit bonfire with dynamic flames and sparks
    for (let i = 0; i < 7; i++) { // Multiple flame elements
      let flameHeight = random(50, 90);
      let flameWidth = random(20, 40);
      fill(255, random(100, 200), 0, random(150, 255)); // Orange-red with transparency
      triangle(0, 0, -flameWidth / 2, -flameHeight, flameWidth / 2, -flameHeight);
    }
    fill(255, 200, 0, 150); // Yellowish inner glow
    ellipse(0, 0, 45, 25); // Larger glow base
    // Sparks
    for (let i = 0; i < 10; i++) {
      fill(255, random(150, 255), 0, random(100, 200));
      ellipse(random(-20, 20), random(-70, -10), random(2, 5));
    }
  } else {
    // Unlit bonfire (logs and ash)
    fill('#6B4226'); // Darker brown for logs
    noStroke();
    rect(-20, -10, 40, 15, 5); // Base log
    rect(-25, -20, 30, 15, 5); // Log 1
    rect(5, -25, 30, 15, 5); // Log 2
    fill('#aaa'); // Grey for unlit ash
    triangle(0, 0, -20, -30, 20, -30);
  }
  pop();

  // Simple fence/border at the bottom
  fill('#D2B48C'); // Tan for fence posts
  stroke('#A0522D'); // Brown for fence lines
  strokeWeight(1);
  for (let i = 0; i < width; i += 40) {
    rect(i, height - 50, 10, 25); // Vertical fence post
    line(i, height - 35, i + 40, height - 35); // Horizontal rail connecting posts
  }
}

// Class for Intro Particles (falling light elements on the intro screen)
class IntroParticle {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = random(width);
    this.y = random(-height, 0); // Start above the screen
    this.size = random(3, 8);
    this.speed = random(0.5, 1.5);
    this.color = color(random(200, 255), random(200, 255), random(200, 255), 150); // Light, transparent color
    this.type = floor(random(2)); // 0: circle, 1: star
  }

  move() {
    this.y += this.speed;
  }

  show() {
    push();
    translate(this.x, this.y);
    fill(this.color);
    noStroke();
    if (this.type === 0) {
      ellipse(0, 0, this.size);
    } else { // Star shape
      let outerRadius = this.size / 2;
      let innerRadius = outerRadius * 0.4;
      let numPoints = 5;
      beginShape();
      for (let a = 0; a < 360; a += 360 / (numPoints * 2)) {
        let radius = (a % (360 / numPoints) === 0) ? outerRadius : innerRadius;
        let sx = cos(a) * radius;
        let sy = sin(a) * radius;
        vertex(sx, sy);
      }
      endShape(CLOSE);
    }
    pop();
  }

  isOffscreen() {
    return this.y > height; // Check if particle is off the bottom of the screen
  }
}

// Class for Floating Elements on the initial screen (background visual)
class FloatingElement {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = random(width);
    this.y = random(height);
    this.size = random(10, 20);
    this.speedX = random(-0.5, 0.5); // Horizontal movement speed
    this.speedY = random(-0.5, 0.5); // Vertical movement speed
    this.color = color(random(150, 255), random(150, 255), random(150, 255), 100); // Soft, transparent colors
    this.type = floor(random(2)); // 0: small balloon, 1: firefly-like glow
  }

  move() {
    this.x += this.speedX;
    this.y += this.speedY;

    // Bounce off the edges of the canvas
    if (this.x < 0 || this.x > width) {
      this.speedX *= -1;
    }
    if (this.y < 0 || this.y > height) {
      this.speedY *= -1;
    }
  }

  show() {
    push();
    translate(this.x, this.y);
    if (this.type === 0) { // Small balloon drawing
      fill(this.color);
      ellipse(0, 0, this.size, this.size * 1.2);
      stroke(this.color.levels[0] * 0.8, this.color.levels[1] * 0.8, this.color.levels[2] * 0.8, 200);
      line(0, this.size * 0.6, 0, this.size * 1.5); // String
    } else { // Firefly-like glow drawing
      noStroke();
      fill(this.color);
      ellipse(0, 0, this.size);
      // Add a subtle glow effect using shadow properties
      drawingContext.shadowBlur = this.size * 0.8;
      drawingContext.shadowColor = this.color;
    }
    pop();
  }

  // Floating elements are designed to bounce, so they never go off-screen.
  isOffscreen() {
    return false;
  }
}

// NEW: Particle class for visual feedback on clicks
class ClickParticle {
  constructor(x, y, color, type = 'square') {
    this.x = x;
    this.y = y;
    this.vx = random(-2, 2);
    this.vy = random(-5, -1);
    this.alpha = 255;
    this.color = color;
    this.size = random(5, 15);
    this.type = type; // 'square', 'circle', 'star'
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += 0.2; // Gravity
    this.alpha -= 5; // Fade out
  }

  display() {
    noStroke();
    fill(this.color.levels[0], this.color.levels[1], this.color.levels[2], this.alpha);
    if (this.type === 'square') {
      rect(this.x, this.y, this.size, this.size);
    } else if (this.type === 'circle') {
      ellipse(this.x, this.y, this.size);
    } else if (this.type === 'star') {
      push();
      translate(this.x, this.y);
      rotate(frameCount * 5); // Rotate stars
      let outerRadius = this.size / 2;
      let innerRadius = outerRadius * 0.4;
      let numPoints = 5;
      beginShape();
      for (let a = 0; a < 360; a += 360 / (numPoints * 2)) {
        let radius = (a % (360 / numPoints) === 0) ? outerRadius : innerRadius;
        let sx = cos(a) * radius;
        let sy = sin(a) * radius;
        vertex(sx, sy);
      }
      endShape(CLOSE);
      pop();
    }
  }

  isFinished() {
    return this.alpha < 0;
  }
}

// NEW: Particle class for bonfire clicks
class BonfireParticle {
  constructor(x, y) {
    this.x = x + random(-10, 10);
    this.y = y + random(-5, 5);
    this.vx = random(-0.5, 0.5);
    this.vy = random(-3, -1);
    this.alpha = 200;
    this.size = random(3, 8);
    this.color = color(255, random(100, 200), 0, this.alpha); // Orange-red
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= 4; // Fade out
  }

  display() {
    noStroke();
    fill(this.color.levels[0], this.color.levels[1], this.color.levels[2], this.alpha);
    ellipse(this.x, this.y, this.size);
  }

  isFinished() {
    return this.alpha < 0;
  }
}